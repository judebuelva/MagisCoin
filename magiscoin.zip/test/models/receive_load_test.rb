require 'test_helper'

class ReceiveLoadTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
