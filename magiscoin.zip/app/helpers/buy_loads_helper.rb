module BuyLoadsHelper
end
