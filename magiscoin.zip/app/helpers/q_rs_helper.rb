module QRsHelper
end
