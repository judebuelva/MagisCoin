class ReceiveLoad < ApplicationRecord
end
